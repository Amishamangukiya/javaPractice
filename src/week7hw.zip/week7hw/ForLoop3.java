package week7hw;

public class ForLoop3 {
    public static void main(String[] args) {
        for (int i=0;i<=50;i=i+2){
            System.out.println("even no between 0 to 50 is  "+i);
        }
    }



}
