package week7hw;

public class ForLoop1 {
    public static void add(int a){

        for(int x=1; x<10; x++){
            System.out.println(x+a);
            }
        }

    public static void main(String[] args) {
        add(5);
    }



        }


