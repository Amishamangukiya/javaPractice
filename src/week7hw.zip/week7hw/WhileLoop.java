package week7hw;

public class WhileLoop {
    public static void main(String[] args) {
        int a=3;
        while(a<8){
            System.out.println(a+100);
            a++;
        }



        }
    }

