package week7hw;

public class DoWhileLoop {
    public static void multiply(){
        int a=5;
        do{
            System.out.println(10*2 +a);
            a++;
        }while(a<=7);
    }

    public static void main(String[] args) {
        multiply();
    }
}


