package week7homework;

public class ArithmeticOperators {
    public static void main(String[] args) {
        int a=10;
        int b=3;
        int x=8;
        int y=7;
        System.out.println(a%b);
        System.out.println(++x);
        System.out.println(--y);
    }
}
