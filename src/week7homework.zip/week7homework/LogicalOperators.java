package week7homework;

public class LogicalOperators {
    public static void main(String[] args) {
        int a=7;
        System.out.println(a>5 && a<12);
        System.out.println(a>5 || a<6);
        System.out.println (!(a>5 && a<12));

    }
}
