package week6homework;

public class DataType2 {
    static byte houseNumber=127;
    static short shopNumber=11000;
    static int customerId=12345678;
    static long myNumber=1234567891;
    static float myHeight=5.4f;
    static double myWeight=51.567;
    static char myCharector='a';
   static boolean itIsMonday=true;
    static String myName="amisha";
    public static void main(String[] args) {


        System.out.println(houseNumber);
        System.out.println(shopNumber);
        System.out.println(customerId);
        System.out.println(myNumber);
        System.out.println(myHeight);
        System.out.println(myWeight);
        System.out.println(myCharector);
        System.out.println(itIsMonday);
        System.out.println("amisha");
    }

}
