package week6homework;

public class DataType1 {



        static byte houseNumber;
        static short shopNumber;
        static int customerId;
        static long myNumber;
        static float myHeight;
        static double myWeight;
        static char myCharector;
        static boolean itIsMonday;
        static String myName;
    public static void main(String[] args) {

        System.out.println(houseNumber);
        System.out.println(shopNumber);
        System.out.println(customerId);
        System.out.println(myNumber);
        System.out.println(myHeight);
        System.out.println(myWeight);
        System.out.println(myCharector);
        System.out.println(itIsMonday);
        System.out.println(myName);
    }

}