package week6homework;

public class DataType {
    public static void main(String[] args) {
        byte houseNumber=127;
        short shopNumber=11000;
        int customerId=12345678;
        long myNumber=1234567891;
        float myHeight=5.4f;
        double myWeight=51.567;
        char myCharector='a';
        boolean itIsMonday=true;
        String myName="amisha";
        System.out.println(houseNumber);
        System.out.println(shopNumber);
        System.out.println(customerId);
        System.out.println(myNumber);
        System.out.println(myHeight);
        System.out.println(myWeight);
        System.out.println(myCharector);
        System.out.println(itIsMonday);
        System.out.println("amisha");
    }
}
