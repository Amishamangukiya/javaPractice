package class11hw;

public class ForEachLoop {
    public static void main(String[] args) {
        String[] arr=new String[]{"Dipak","Palak","Mahek"};
        for(String i:arr)
            System.out.println(i);
    }
}
