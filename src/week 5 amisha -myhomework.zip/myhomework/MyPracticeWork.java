package myhomework;

public class MyPracticeWork {
    public static void main(String[] args) {

         String name = "Amisha";
        System.out.println(name);

         int myAge = 40;
        System.out.println(myAge);

         int myNum =15;
         myNum =16;  //myNum is now 16
        System.out.println(myNum);


    }    }


