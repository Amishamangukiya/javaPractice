package myhomework;

public class MyMethod {
    public static void main(String[] args) {


        // create a method
        int addNumbers;
        int subNumbers;
        int a = 15;
        int b = 10;
        System.out.println(a + b);
        System.out.println(a - b);
    }





    }




