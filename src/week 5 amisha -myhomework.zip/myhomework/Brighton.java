package myhomework;

public class Brighton {

    public static void main(String[] args) {

        System.out.println("It is a small town");
        System.out.println("It is situated on beach");
        System.out.println("It is a pebble beach");
        System.out.println("It has many historical building");// about brighton
    }
}
